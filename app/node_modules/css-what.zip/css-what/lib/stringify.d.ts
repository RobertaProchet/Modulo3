import { Selector } from "./parse";
/**
 * Turns `selector` back into a string.
 *
 * @param selector Selector to stringify.
 */
export default function stringify(selector: Selector[][]): string;
//# sourceMappingURL=stringify.d.ts.map